#include "STD.h"
#include "hexadecimal.h"

unsigned int atox(char* hexStr)
{
	unsigned char uc, hexChar;
	unsigned int hex = 0, hex_sum=0;
	for (int i = 0; i < MAX_HEX_STR_LEN; i++)
	{
		if (hexStr[i] == NULL) //hexChar == NULL�̸� break
			return hex_sum;
		if ((hexStr[i] >= '0') && (hexStr[i] <= '9')) //0~9
			hex = hexStr[i] - '0';
		else if ((hexStr[i] >= 'A') && (hexStr[i] <= 'F')) //10~15(A~F) ���ڰ� �빮���ΰ��
			hex = hexStr[i] - 'A' + 10;
		else if ((hexStr[i] >= 'a') && (hexStr[i] <= 'f')) //10~15(a~f) ���ڰ� �ҹ����ΰ��
			hex = hexStr[i] - 'a' + 10;	//10���� 1A�̹Ƿ� +10
		else //16������ �ƴѰ��
		{
			printf("Input ERROR!!\n");
			exit(-1);
		}
		hex_sum = (hex_sum << 4) + hex;
	}
	return hex_sum; //10���� �� ��ȯ
}

void xtoa(char* str_hex, int value)
{
	char temp = 0;
	char str[MAX_HEX_STR_LEN] = { 0 };
	for (int i = MAX_HEX_STR_LEN-1; i >= 0; i--)
	{
		temp = ((value << (i*4))>>28);
		if (temp == 0)
			continue;
		if (temp < 10 && temp >= 0)
			temp = temp + '0';
		else if (temp >= 10 && temp <= 15)
			temp = temp + 'A' - 10;
		str[i] = temp;
		//strcpy(str_hex, str);
		//str_hex[i] = str[i];
	}
}