#ifndef HEX
#define HEX
#define MAX_HEX_STR_LEN 8
unsigned int atox(char* hexStr);
void xtoa(char* str_hex, int value);
//void xtoa(char* strBuf, unsigned int hxd);
#endif